// Copyright Epic Games, Inc. All Rights Reserved.

#include "U04_MultiPlay.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, U04_MultiPlay, "U04_MultiPlay" );
 